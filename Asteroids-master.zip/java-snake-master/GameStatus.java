
public enum GameStatus
{
    NOT_STARTED, RUNNING, PAUSED, GAME_OVER
}
