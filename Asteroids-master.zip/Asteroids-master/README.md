# Asteroids

New spin on an old game. Design a geometric spaceship and shoot at asteroids. There are powered-up weapons and mysterious status effects to keep it interesting, as well as extra kinds of asteroids that show up as you progress through each wave.

Play by yourself with with a friend (though I'm not sure if one keyboard can handle simultaneous inputs for two users).

## Download

See the [releases page](https://github.com/evanw555/Asteroids/releases/) to download the game. The game runs as a standalone JAR, as it was developed purely using built-in Java graphics and GUI components.
