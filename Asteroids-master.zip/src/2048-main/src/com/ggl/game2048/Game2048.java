
/* 
file principale per eseguire il gioco 
Descrizione gioco: il seguente gioco arcade ,2048;utiizzando le potenze del 2 , si deve arivare a 2048 per vincere 
avendo a disposizione una matrice 4X4 . è presente il tasto start e hight score per vedere il massimo punteggio
codice interamente sviluppato in java  , utilizzando Swing

*/
package com.ggl.game2048;

import javax.swing.SwingUtilities;

import com.ggl.game2048.model.Game2048Model;
import com.ggl.game2048.view.Game2048Frame;

public class Game2048 implements Runnable {

    
   @Override
   public void run() {
       new Game2048Frame(new Game2048Model());
   }
    
   public static void main(String[] args) {
       SwingUtilities.invokeLater(new Game2048());
   }

}
