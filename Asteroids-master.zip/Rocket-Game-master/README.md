# Rocket-Game

As a final Java project
Completed in 2 days
Optimizes the object oriented programming concept
Earned me an A :D ;)

It has some few glitches which I'd appreciate your contribution to fix.
Just submit your contributions as appropriate.
